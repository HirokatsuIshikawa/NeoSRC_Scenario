﻿
using UnityEngine;

[System.Serializable]
public class CardBaseData 
{
    public string name;
    public Sprite sprite;
    public int value;
    public float scale;
}
